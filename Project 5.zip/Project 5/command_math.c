#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//Anton Shepelev. U28654378. This program accepts as command line arguments the sign of a math operation (+, -, x, or /) and two integer numbers and displays the result of the operation (all integer operations. //
 int main(int ops, char *argument[])
{//The program checks the input and verifies what operation was asked by checking 4 possible cases//
    int output, jopa;
    //Case 1: Addition (+)
    if(strcmp(argument[1], "+") == 0)
        output = jopa = atoi(argument[2]) + atoi(argument[3]);
    //Case 2: Subtraction (-)
    if(strcmp(argument[1], "-") == 0)
        output = jopa = atoi(argument[2]) - atoi(argument[3]);
    //Case 3: Multiplication (x)
    if(strcmp(argument[1], "x") == 0)
        output = jopa = atoi(argument[2]) * atoi(argument[3]);
    //Case 4: Devision (/)
    if(strcmp(argument[1], "/") == 0)
        output = jopa = atoi(argument[2]) / atoi(argument[3]);

    //OUTPUT PRINT. Validation of Given Operation//
    if(jopa==output)
        printf("\nResult:%d\n", output);
    else printf("Your operation can't be done. Make sure it is one of the following: +,-,x,or /\n");
    return 0;
}
