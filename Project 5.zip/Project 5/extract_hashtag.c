#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
//Anton Shepelev. U28654378. This program checks if a sentence entered by user contains a hashtag. //
//Output:if so,display the hashtag. If not, print a no hashtag message. If there are multiple hashtags in the input, display the first one. //
int find_hashtag(char *s1, char *s2);
int read_line(char *str, int n);
int main()
{
    char input[1000]; char output[100] = {'\0'};

    //Prompt Input//
    printf("Input: ");
    read_line(input,1000);
    int result = find_hashtag(input, output);

    //Output//
    printf("Output: ");
    if(result==1)
        printf("%s",output);
    if(result==0)
        printf("No hashtag in the input");
    return 0;
}
int read_line(char *str, int n)
{//The function stores user's input
          int ch; int i = 0;

          while ((ch = getchar()) != '\n')
          {  if (i < n)
             { *str++= ch;
                i++;
             }
          }
          *str = '\0';   /* terminates string */
          return i;        /* number of characters stored */
}

int find_hashtag(char *s1, char *s2)
{//The function returns 1 if the input contains a hashtag, and returns 0 otherwise.//
char *temp=s1;
    for (;*temp!='\0';temp++)
    {
    if (*temp=='#' && (*(temp+1)=='_' || (isalnum(*(temp+1)))  )  )
        {
            temp++;
        for (;*temp!= '\0';temp++)
            {
                if (*temp!='_' && !isalnum(*temp))
                {
                    return 1;
                }
                *s2=*(temp);
                s2++;
            }
            return 1;
        }
    }
    return 0;
}
