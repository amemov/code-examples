#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int main()
{
   /* int *p1,*p2,i,j;
    p1 = &i;
    p2 = &j;
    *p1 = 10;
    *p2 = 20;
    printf("p1 is %d  and i is %d\n",*p1,i);
    printf("p2 is %d  and j is %d\n",*p2,j);
    i = 100;
    printf("p1 is %d  and i is %d\n",*p1,i);*/
    int *p, *q;
    int i = 4, j = 4;
    p = &i;
    q = &j;
    printf("i is %d and *p is %d\n", i, *p);
    printf("&i is %p and p is %p\n", &i, p);

    printf("i is %d and *q is %d\n", i, *q);
    printf("&i is %p and q is %p\n", &i, q);
    *p = 32;
    printf("\n \n NEXT \n \n ");
    printf("\n \n NEXT \n \n ");
    printf("i is %d and *p is %d\n", i, *p);
    printf("&i is %p and p is %p\n", &i, p);

    printf("i is %d and *q is %d\n", i, *q);
    printf("&i is %p and q is %p\n", &i, q);
    return 0;
}
