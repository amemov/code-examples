#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define N 10
//Anton Shepelev. U28654378. This program randomizes the key array (size 10) (swaps positions of 2 different digits 10 times) //
//And does basic encryption of a numeric password                                                                             //
void replace(int a[], int b[],int key[],int n);
void swap(int a[],int n);
int main()
{
    int i,size;
    srand(time(NULL));
    printf("Enter the number of digits of the number: ");
    scanf("%d",&size);
//Checks if the integer is positive //
    while(size<0)
    {
        printf("Error.Enter the number of digits of the number: ");
        scanf("%d",&size);
    }

    int tara[size],key[10] = {0,1,2,3,4,5,6,7,8,9},output[size];
//Prompt the number //
    printf("Enter the number: ");
    for(i = 0; i<size; i++)
        scanf("%1d",&tara[i]);
//Generate the Key //
    swap(key,N);
    printf("Key array: ");
    for(i=0;i<N;i++)
    {
        printf("%d ",key[i]);
    }
    //to double check
    printf("\nOriginal Number: ");
    for(i=0;i<size;i++)
    {
        printf("%d ",tara[i]);
    }

    replace(tara,output,key,size);
    printf("\nOutput: ");
    for(i=0;i<size;i++)
    {
        printf("%d ",output[i]);
    }
    return 0;
}
void replace(int a[], int b[],int key[],int n)
{   //a = tara; b = output ; key = key ; n = size//
    int i,proverka; // Used to check the indexes in the array
    for (i=0;i<n;i++)
    {
        proverka = 0;
        while(a[i]!=key[proverka])
        {
                proverka++;
        }
        b[i]=proverka;
    }
}
void swap(int a[],int n)
{
    int num1 = 0,num2 = 0;
    int temp1 = 0; int temp2 = 0;
    int middle_var = 0;
    while(n>=0)
    {
        //Generates 2 random numbers //
        num1 =(rand()%(10))+0;
        num2 =(rand()%(10))+0;
        //Writes down the numbers //
        temp1 = a[num1];
        temp2 = a[num2];
        //Swaps the 2 numbers positions in the array //
        middle_var = temp1;
        a[num1] = temp2;
        a[num2] = middle_var;
        n--;
    }
}
