 #include <stdio.h>
 #include <time.h>
 int main ()
 {
    int x, sum = 0;
    printf("x is %d",x);
     return 0;
 }




