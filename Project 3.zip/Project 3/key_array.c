#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define N 10
//Anton Shepelev. U28654378. This program swaps two digits in the array (0,1...,9) 10 times. //
void swap(int a[],int n);
int main()
{
    int i;
    int baza [10] = {0,1,2,3,4,5,6,7,8,9};
    srand(time(NULL));
//Original array //
    printf("Original array: ");
    for(i=0;i<N;i++)
    {
        printf("%d ",baza[i]);
    }

    printf("\n");
    swap(baza,N);
//Output: swaped array //
    printf("Output: ");
    for(i = 0;i<10;i++)
        printf("%d ",baza[i]);

    return 0;
}
void swap(int a[],int n)
{
    int num1 = 0,num2 = 0;
    int temp1 = 0; int temp2 = 0;
    int middle_var = 0;
//Recursion: executes 10 times //
    while(n>=0)
    {
        //Generates 2 random numbers //
        num1 =(rand()%(10))+0;
        num2 =(rand()%(10))+0;
        //Writes down the numbers //
        temp1 = a[num1];
        temp2 = a[num2];
        //Swaps the 2 numbers positions in the array //
        middle_var = temp1;
        a[num1] = temp2;
        a[num2] = middle_var;
        n--;
    }
}
