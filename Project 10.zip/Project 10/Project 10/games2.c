#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#define STR_LEN 100
#define GAME_LEN 100
//Anton Shepelev. U28654378.
/***                    This program scans input file, sorts the games based on amount of sales,                                ***/
/***                         and writes sorted data in "sorted_*input file name*.txt"                                           ***/
//struct for a game
struct game {
    int sold;
    int stock;
    char name[STR_LEN+1];};

void sort_games(struct game list[], int n);
int compare(const void *one, const void *two);
int main()
{
    char input_name[STR_LEN+1]; char output_name[STR_LEN+1] = "sorted_"; int array_len = 0, i = 0;
//!Prompt file name//
         printf("Enter the file name: ");
         fgets(input_name, STR_LEN, stdin);
        //removes "\n" character from string
        input_name[strcspn(input_name,"\n")] = 0;

        //input validation
         FILE* inital = fopen(input_name, "r");
         if(inital == NULL)
         {
            printf("\nError opening the file.");
            return 1;
         }

        ////appending file name to "sorted_"
        strcat(output_name,input_name);
        printf("Output file name: %s", output_name);

//!Scan data. Count lines and then !Initialize struct!

        struct game videogame[GAME_LEN];
        // == 3 means that compiler successfully scans 3 parameters //
        while(fscanf(inital, "%d %d %[^\n]s", &videogame[array_len].sold, &videogame[array_len].stock, videogame[array_len].name)==3)
        {
                array_len++;
        }
        fclose(inital);

//!Sorting data -> method below
        qsort(videogame, array_len, sizeof(struct game), compare);

//!Write sorted data in the output file
        FILE* output = fopen(output_name, "w");
        for(i = 0; i < array_len; i++)
            fprintf(output, "%d %d %s\n", videogame[i].sold, videogame[i].stock, videogame[i].name);

    return 0;
}
//This function compares 2 listings in the struct by !quantity of sold games!
int compare(const void *one, const void *two)
{
    //!Negative: "one" is BIGGER than "two"; //
    //!Zero: they are equal;               //
    //!Positive: "one" is LESS than "two"//
    return((struct game *)one)->sold < ((struct game *)two)->sold;
}
//This method sorts games in descending order ( from highest sales to lowest sales )
//p.s. I was not sure what the teacher meant by "sorts the games in quantity", so I assumed it was just number of sales//
//Below is modified method from Week 10 InClass exercise                                                               //
/*void sort_games(struct game list[], int n)
{
    int i, largest = 0;
    struct game temp;

    if (n == 1)
        return;

    for (i = 1; i < n; i++)
        if (list[i].sold < list[largest].sold)
              largest = i;


    if (largest < n - 1) {
        temp = list[n-1];
        list[n-1] = list[largest];
        list[largest] = temp;
    }

    sort_games(list, n - 1);
}                                                   */
