#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "request.h"
//Anton Shepelev. U28654378//
/*******************************************************************************
**                                                                            **
**                          This is a source file.                            **
**          It has functions in the following order that:                     **
**            (1)Insert to Order (previously:Append to List Permit)           **
**            (2)Update Status (granted/declined)                             **
**            (3)Print  Permits                                               **
**            (4)Clear  Permits List                                          **
**                                                                            **
**                                                                            **
*******************************************************************************/
//This function prompts user courseID and studentID; It checks if there is permit in the list. If not, it creates new permit//
struct request *insert_to_list(struct request *list){

    char courseID[COURSE_LEN+1]; char studentID[NAME_LEN+1];
    char first[NAME_LEN+1]; char last[NAME_LEN+1];
    char status[STATUS_LEN+1] = "Pending";

    //!Prompt Course and Student ID//
    printf("Course ID: ");
    read_line(courseID, COURSE_LEN+1);
    printf("Student ID: ");
    read_line(studentID, NAME_LEN+1);

    //!CHECK IF THERE IS A PERMIT//
    int CHECK = 0;

        struct request *before, *temp;
        for(temp = list; temp != NULL ;temp = temp->next)
       {
           if (strcmp(temp->studentID, studentID) == 0 && strcmp(temp->courseID, courseID) == 0)
               CHECK = 1;
       }
       if(CHECK == 1)
       {
            printf("Request already exists.");
                return list;
       }
       //!IF THERE IS NO PERMIT IN THE LIST//
       if(CHECK == 0)
       {
            //Prompt: First Name / Last Name
            printf("\tEnter the Data for Permit\t\n");

                printf("First name: ");
                read_line(first,NAME_LEN+1);
                printf("Last name: ");
                read_line(last,NAME_LEN+1);

            //fulfilling struct//
            struct request *new_permit = (struct request*) malloc(sizeof(struct request));
            if(list == NULL)
                   {
                            // 1. courseID ; 2. student ID ; 3. first 4. last ; 5. status [by default = Pending]//
                            /*1*/strcpy(new_permit->courseID,courseID);
                            /*2*/strcpy(new_permit->studentID,studentID);
                            /*3*/strcpy(new_permit->first,first);
                            /*4*/strcpy(new_permit->last,last);
                            /*5*/strcpy(new_permit->status,status);

                                list = new_permit;

                   }
                        //in case the 1st position is occupied//
                   else
                   {
                            temp = list;
                            before = NULL;
                            //going through the list to: check the position of course and student ID
                            while(temp != NULL)
                            {
                                    //if temp's studentID is bigger -> exit the loop
                                    if(strcmp(temp->courseID, courseID) > 0 )
                                    {
                                        break;
                                    }
                                    //if temp's courseID is bigger -> exit the loop
                                    else if((strcmp(temp->courseID, courseID)==0) && (strcmp(temp->studentID, studentID) > 0 ))
                                    {
                                        break;
                                    }
                                    before = temp;
                                    temp = temp->next;

                            }

                            // 1. courseID ; 2. student ID ; 3. first 4. last ; 5. status [by default = Pending]//
                            /*1*/strcpy(new_permit->courseID,courseID);
                            /*2*/strcpy(new_permit->studentID,studentID);
                            /*3*/strcpy(new_permit->first,first);
                            /*4*/strcpy(new_permit->last,last);
                            /*5*/strcpy(new_permit->status,status);


                            if(before == NULL)
                            {
                                new_permit->next = list;
                                list = new_permit;
                            }
                            else
                            {   //putting new_permit in between temp and "before"
                                new_permit->next = temp;
                                before->next = new_permit;
                            }
                    }


            printf("\n\tSUCCESS. PERMIT CREATED\t");
       }
       return list;

}


//!OLDER VERSION!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

/*struct request *append_to_list(struct request *list){

 char courseID[COURSE_LEN+1];char studentID[NAME_LEN+1];
 char first[NAME_LEN+1]; char last[NAME_LEN+1];
 char status[STATUS_LEN+1] = "Pending";

 printf("\n**APPEND NEW PERMIT TO THE LIST**\n");
 //!PROMPT                    //

 printf("Course ID: ");
 read_line(courseID, COURSE_LEN+1);
 printf("Student ID: ");
 read_line(studentID, NAME_LEN+1);

 //!CHECK IF THERE IS A PERMIT//
   struct request *temp;
   int CHECK = 0;
   for(temp = list; temp != NULL ;temp = temp->next)
   {
       if (strcmp(temp->studentID, studentID) == 0 && strcmp(temp->courseID, courseID) == 0)
           CHECK = 1;
   }
   if(CHECK == 1)
   {
        printf("Request already exists.");
   }
 //!IN CASE THERE IS NO PERMIT//
    if(CHECK == 0)
    {
        printf("\tEnter the Data for Permit\t\n");

        printf("First name: ");
        read_line(first,NAME_LEN+1);
        printf("Last name: ");
        read_line(last,NAME_LEN+1);

        //fulfilling struct//
        struct request *new_permit =  (struct request*) malloc(sizeof(struct request));
        //malloc check
                        if (new_permit == NULL) {printf("\nMALLOC FAILED in add_to_list\n"); return NULL;}
            //if list is empty
            if(list == NULL)

                // 1. courseID ; 2. student ID ; 3. first 4. last ; 5. status [by default = Pending]//
                /1///strcpy(new_permit->courseID,courseID);
                /2///strcpy(new_permit->studentID,studentID);
                /3///strcpy(new_permit->first,first);
                /4///strcpy(new_permit->last,last);
                /5///strcpy(new_permit->status,status);

                    //list = new_permit;

            }
            //in case the 1st position is occupied//
            else
            {

                struct request *temp = list;
                // 1. courseID ; 2. student ID ; 3. first 4. last ; 5. status [by default = Pending]//
                /1///strcpy(new_permit->courseID,courseID);
                /2///strcpy(new_permit->studentID,studentID);
                /3//strcpy(new_permit->first,first);
                /4///strcpy(new_permit->last,last);
                /5///strcpy(new_permit->status,status);

               //Goes through list until it faces NULL//
                while(temp->next!= NULL)
                    temp = temp->next;
                temp->next = new_permit; //Assigning new_permit to the end//

            }
            new_permit->next = NULL;
            printf("\n\tSUCCESS. PERMIT CREATED\t");

    }

 return list;

}*/
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//This function updates status based on courseID and studentID information//
void update(struct request *list)
{
    char courseID[COURSE_LEN+1];char studentID[NAME_LEN+1];
    char coder;
    printf("\n**UPDATE OF THE PERMIT STATUS**\n");

    printf("Student ID: ");
    read_line(studentID, NAME_LEN+1);
    printf("\nCourse ID: ");
    read_line(courseID, COURSE_LEN+1);

    //!Searching permit//
    struct request *temp;

    for(temp = list; temp!=NULL; temp = temp->next)
    {   //validating that there is such student in the course//
        if (strcmp(temp->studentID, studentID) == 0 && strcmp(temp->courseID, courseID) == 0)
        {
                printf("Set status code to granted or declined ( g / d ): ");
                scanf(" %c", &coder);
                while (getchar() != '\n')   /* skips to end of line */
                ;
                switch (coder)
                {
                    case 'g': strcpy(temp->status,"Granted"); break;    case 'G': strcpy(temp->status,"Granted");  break;
                    case 'd': strcpy(temp->status,"Declined");break;    case 'D': strcpy(temp->status,"Declined"); break;

                    default: printf("Illegal code\n");
                }
                printf("\n\tSUCCESS. STATUS UPDATED\t");

                break;
        }
    }
}

//This function prints ALL permits in the list//
void printList(struct request *list){

  struct request *printer;
  //Is the list empty???
  if(list == NULL)
    printf("THE LIST IS EMPTY");
  else
  {
     printf("\n\t\t\t\t**LIST OF PERMITS**\n");
     printf("\tCourse ID\tStudent ID\tStatus\t\tLast Name\tFirst Name\n");

     for(printer = list; printer!=NULL; printer = printer->next)
        printf("\t%8s\t%8s\t%8s\t%8s\t%8s\n", printer->courseID,printer->studentID,printer->status,printer->last, printer->first);
  }

}
//This function cleans ALL permits in the list//
void clearList(struct request *list)
{
  //code that was covered in the last lecture//
  struct request *p;
  while(list != NULL)
  {
	 p = list;
      list = list->next;
      if( p!= NULL)
           free(p);
  }
  printf("\n**THE LIST WAS SUCCESSFULLY CLEARED**\n");
}

