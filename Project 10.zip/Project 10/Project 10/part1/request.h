#ifndef REQUEST_H       //! begin REQUEST_H

#define COURSE_LEN 100          //! CONSTANTS
#define NAME_LEN 30
#define STATUS_LEN 30
#define REQUEST_H

struct request{                 //! STRUCT
	char courseID[COURSE_LEN+1];
	char studentID[NAME_LEN+1];
	char first[NAME_LEN+1];
	char last[NAME_LEN+1];
	char status[STATUS_LEN+1];
	struct request *next;
};
                                //! PROTOTYPES
struct request *insert_to_list(struct request *list);
void update(struct request *list);
void printList(struct request *list);
void clearList(struct request *list);
int read_line(char str[], int n);

#endif                  //! end REQUEST_H
